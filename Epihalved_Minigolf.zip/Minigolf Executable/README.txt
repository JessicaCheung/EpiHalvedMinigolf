Epihalved
Jessica Cheung
Thomas Deeb
Minigolf

Run the file "Minigolf.exe"

Controls
W - Increase power
S - Decrease power
A - Move direction right
D - Move direction left
Spacebar - Hit golfball
Enter - Switch hole
T - Top view camera
F - Free look camera
G - Third person view

Mouse
Right-click for model manipulation options
	Then Left-click/right-click
Scroll wheel will zoom in/out camera