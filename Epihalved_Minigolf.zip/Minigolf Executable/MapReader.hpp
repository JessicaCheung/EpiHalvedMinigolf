/*#pragma once
#include "main.hpp"
#include "Map.hpp"

void ReadFile(string filename, vector<Tile>& Tiles, ImportObj& Tee, ImportObj& Cup);
void ReadVertices(fstream file, vector<Tile>& Tiles, ImportObj& Tee, ImportObj& Cup);
void ParseLine(vector<string> lines, vector<Tile>& Tiles, ImportObj& Tee, ImportObj& Cup);
void ParseTile(vector<string> lines, vector<Tile>& Tiles);
void ParseTeeCup(vector<string> lines, ImportObj& obj);
vector<string> SplitString(const char *str, char c = ' ');
void load_obj(const char* filename, vector<glm::vec3> &vertices, vector<int> &elements, glm::vec3 coor);*/